import React from "react";

const AdminProductos = () => {
  return (
    <div>
      <h2>Gestión de productos</h2>
      <p>Aquí podrás añadir, editar o eliminar productos.</p>
    </div>
  );
};

export default AdminProductos;
